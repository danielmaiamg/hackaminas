<?php
/**
 * PHP GeoJSON Constructor, adpated from https://github.com/bmcbride/PHP-Database-GeoJSON
 */
# Connect to MySQL database
$conn = mysqli_connect('localhost', 'root', '123456', 'hackaton');

if (mysqli_connect_errno())
{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

/*
$ano = $_GET['ano'];
$mes = $_GET['mes'];
$dia = $_GET['dia']; 
*/

# However the User's Query will be passed to the DB:
#$sql = 'SELECT id, logradouro, longitude, latitude from json2 WHERE (servico = "Reforma de bueiros, boca de lobo e poços de visita" OR servico = "Limpeza de bueiros, boca de lobo e poços de visita") AND (data_de_abertura like "' . $ano . '-' . $mes . '-' . $dia . '")';
$sql = 'SELECT id, logradouro, longitude, latitude from json2 WHERE (servico = "Reforma de bueiros, boca de lobo e poços de visita" OR servico = "Limpeza de bueiros, boca de lobo e poços de visita") limit 200';


# Try query or error
$rs = mysqli_query($conn, $sql);

if (!$rs) {
    echo 'An SQL error occured.\n';
    exit;
}

# Build GeoJSON feature collection array
$geojson = array(
   'type'      => 'FeatureCollection',
   'features'  => array()
);

# Loop through rows to build feature arrays
while($row = mysqli_fetch_assoc($rs)) {
    $feature = array(
        'id' => $row['id'],
        'type' => 'Feature', 
        'geometry' => array(
            'type' => 'Point',
            # Pass Longitude and Latitude Columns here
            'coordinates' => array($row['longitude'], $row['latitude'])
        ),
        # Pass other attribute columns here
		'properties' => array(
            'Logradouro' => $row['logradouro']
            )
        );
    # Add feature arrays to feature collection array
    array_push($geojson['features'], $feature);
}

header('Content-type: application/json');

echo json_encode($geojson, JSON_NUMERIC_CHECK);

mysqli_close($conn);
?>