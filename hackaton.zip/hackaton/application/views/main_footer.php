<?php 
	
	if($this->session->userdata('LOGON') != TRUE): 

		redirect('/main/', 'refresh');
	
	endif;
		
?>

  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      <strong>Versão 1.0</strong>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2018 <a href="#">HackaMinas</a>. </strong> Todos os direitos reservados.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>

      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Atividades Recentes</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa bg-red"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Atividade não informada</h4>

                <p>Recurso indisponível</p>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

      </div>
      <!-- /.tab-pane -->
      <!-- Stats tab content -->
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      <div class="tab-pane" id="control-sidebar-settings-tab">
        <form method="post">
          <h3 class="control-sidebar-heading">Configurações Gerais</h3>
		  
		  <p>Recurso desabilitado</p>
		  
        </form>
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- REQUIRED JS SCRIPTS -->

<!-- AdminLTE App -->
<script src="<?php echo base_url("application/views/"); ?>dist/js/app.min.js"></script>

<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url("application/views/"); ?>dist/js/demo.js"></script>

<!-- Select2 -->
<script src="<?php echo base_url("application/views/"); ?>plugins/select2/select2.full.min.js"></script>
<script src="<?php echo base_url("application/views/"); ?>plugins/select2/i18n/pt-BR.js"></script>

<!-- InputMask -->
<script src="<?php echo base_url("application/views/"); ?>plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?php echo base_url("application/views/"); ?>plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?php echo base_url("application/views/"); ?>plugins/input-mask/jquery.inputmask.extensions.js"></script>

<!-- bootstrap datepicker -->
<script src="<?php echo base_url("application/views/"); ?>plugins/datepicker/bootstrap-datepicker.js"></script>

<script>
  $(function () {
  
	//Initialize Select2 Elements
    $(".select2").select2({language: "pt-BR"});

    //Datemask dd/mm/yyyy
    $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    //Datemask2 mm/dd/yyyy
    $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
    //Money Euro
    $("[data-mask]").inputmask();
	
	//Date picker
    $('#datepicker').datepicker({
      autoclose: true
    });

	//Date picker
    $('#datepicker2').datepicker({
      autoclose: true
    });

  });
</script>

</body>
</html>
