<?php 
	
	if($this->session->userdata('LOGON') != TRUE): 

		redirect('/main/', 'refresh');
	
	endif;
	
	$icone_tempo = array(
		'ec' => '',
		'ci' => 'ion-ios-rainy',
		'c' => 'ion-ios-rainy',
		'in' => '',
		'pp' => '',
		'cm' => 'ion-ios-rainy',
		'cn' => 'ion-ios-rainy',
		'pt' => '',
		'pm' => '',
		'np' => '',
		'pc' => '',
		'pn' => 'ion-ios-cloudy',
		'cv' => 'ion-ios-rainy',
		'ch' => 'ion-ios-rainy', 
		't' => 'ion-ios-thunderstorm',
		'ps' => 'ion-ios-sunny',
		'e' => 'ion-ios-partlysunny',
		'n' => 'ion-ios-partlysunny',
		'nv' => '',
		'g' => 'ion-ios-snowy',
		'ne' => 'ion-ios-snowy',
		'nd' => '',
		'pnt' => '',
		'psc' => '',
		'pcm' => '',
		'pct' => '',
		'pcn' => '',
		'npt' => '',
		'npn' => '',
		'ncn' => '',
		'nct' => '',
		'ncm' => '',
		'npm' => '',
		'npp' => '',
		'vn' => 'ion-ios-cloudy',
		'ct' => '',
		'ppn' => '',
		'ppt' => '',
		'ppm' => '',
		'nppc' => '',
		'nppcm' => '',
		'nppct' => '',
		'nppcn' => '');		
	
	function convertDataDiaMes($data){
	
		$newdata=explode("-", $data)[2]."/".explode("-", $data)[1];
		
		return $newdata;
	}


	function importTabTime($arquivo){
	
		foreach ($arquivo as $dado) {
		
			 $arqSplit = explode(",", $dado);
			 $novo[$arqSplit[0]] = $arqSplit[1];
		
		}
	
		return $novo;
	}
	
	function retTime($tempo){
		
		return sprintf("%s", $tempo);
		
	}

	function convertTime($tempo, $novo){
		
		return $novo[retTime($tempo)];
		
	}

	function mostraImgTime($tempo, $icone_tempo){
		
		return $icone_tempo[retTime($tempo)];
		
	}
	
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard - SP156
        <small>Painel de Controle</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url(); ?>"><i class="fa fa-dashboard"></i> Painel</a></li>
        <li class="active">Inicial</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	<!-- START -->
	  <!-- Main row -->
	  <div class="row">

		<div class="box">
            <div class="box-header">
              <h3 class="box-title">Filtro das Informações</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
			
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
						
							<label for="filtros">
							Selecione a(s) palavra(s)-chave que deseja aplicar como termo de risco de alagamento:<br/>
							<select id="filtros" name="filtros[]" class="select2 form-control" multiple="multiple" style="width: 206%;">
								<option value="1">Chuva</option>
								<option value="2">Inunda</option>
								<option value="3">Entupimento</option>
								<option value="4">Entope</option>
								<option value="5">Enchente</option>
								<option value="6">Alagamento</option>
							</select>
							</label>
							
						</div>
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-6">
					  <div class="form-group">
						<label>Período Inicial da Consulta:</label>

						<div class="input-group date">
						  <div class="input-group-addon">
							<i class="fa fa-calendar"></i>
						  </div>
						  <input type="text" class="form-control pull-right" id="datepicker" name="datepicker">
						</div>
						<!-- /.input group -->
					  </div>
					</div>				

					<div class="col-md-6">
					  <div class="form-group">
						<label>Período Final da Consulta:</label>

						<div class="input-group date">
						  <div class="input-group-addon">
							<i class="fa fa-calendar"></i>
						  </div>
						  <input type="text" class="form-control pull-right" id="datepicker2" name="datepicker2">
						</div>
						<!-- /.input group -->
					  </div>

					</div>				
					
				</div>
			  
            </div>
            <!-- /.box-body -->
			
			<div class="box-footer">
				<button type="submit" class="btn bg-olive pull-right" id="aplicar">Aplicar Filtro(s)</button>
            </div>
						
			<div id="loading1" class="overlay" style="visibility: hidden">
			  <i class="fa fa-refresh fa-spin"></i>
			</div>			 
			
          </div>
          <!-- /.box -->

		  </form>
		  <div id="simple-msg1"></div>
		  
		  <div id="table-data"></div>
	  
	  </div>
	  
      <div class="row">
        <!-- Left col -->
        <div class="col-md-12">
          <!-- MAP & BOX PANE -->
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Limpeza de bueiros, bocas de lobo e poços de visita</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="row">
                <div class="col-md-9 col-sm-8">
                  <div class="pad">
                    <!-- Map will be created here -->
                    <div id="quadro_mapa" style="margin-top: -1%; width: 105%; height: 390px; background: #000;"></div>
                  </div>
                </div>
                <!-- /.col -->
                <div class="col-md-3 col-sm-4">
                  <div class="pad box-pane-right bg-green" style="min-height: 280px">
                    <div class="description-block margin-bottom">
                      <div class="sparkbar pad" data-color="#fff"></div>
                      <h5 class="description-header" style="font-size: 220%"><?php echo $total['quant']; ?></h5>
                      <span class="description-text">Total de Ocorrências</span>
                    </div>
                    <!-- /.description-block -->
                    <div class="description-block margin-bottom">
                      <div class="sparkbar pad" data-color="#fff"></div>
                      <h5 class="description-header" style="font-size: 220%"><?php echo $reforma['quant']; ?></h5>
                      <span class="description-text">Ocorrências de Reforma</span>
                    </div>
                    <!-- /.description-block -->
                    <div class="description-block">
                      <div class="sparkbar pad" data-color="#fff"></div>
                      <h5 class="description-header" style="font-size: 220%"><?php echo $limpeza['quant']; ?></h5>
                      <span class="description-text">Ocorrências de Limpeza</span>
                    </div>
                    <!-- /.description-block -->
                    <div class="description-block">
                      <div class="sparkbar pad" data-color="#fff"></div>
                      <h5 class="description-header" style="font-size: 220%"><?php echo $risco['quant'] . " (".$risco_percentual."%)"; ?></h5>
                      <span class="description-text">Risco de Alagamentos</span>
                    </div>
                    <!-- /.description-block -->
					
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
		
	  </div>
	  
	  <div class="row">
	  
	  <?php

		$arquivo=file(base_url("application/views/") . "dados.txt");
		$novo=importTabTime($arquivo);

		//importação arquivo xml previsao tempo.
		$link="http://servicos.cptec.inpe.br/XML/cidade/244/previsao.xml"; //link do arquivo xml

		$xml = simplexml_load_file($link);  //carrega o arquivo XML e retornando um Array


			foreach($xml->previsao as $dados){
		
	  ?>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="ion <?php echo mostraImgTime($dados->tempo, $icone_tempo);?>" style="font-size: 80%"><br/><?php echo convertDataDiaMes($dados-> dia);?></i></span>

                <div class="info-box-content">
                  <span class="info-box-text"><?php echo convertTime($dados->tempo, $novo); ?></span>
                  <span class="info-box-number"><small>Máxima:</small><?php echo $dados -> maxima; ?>&ordm;<br/>
				  <small>Mínima:</small><?php echo $dados -> minima; ?>&ordm;</span>
                </div>
                <!-- /.info-box-content -->
              </div>
			  
			</div>
			
		<?php
		
		}
		
		?>
				
	  </div>
	
	<!-- END -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
<script>
	//variavel para configurar elemento mapa e dar informacoes iniciais
	var mapa = L.map('quadro_mapa', {center: [-23.5676, -46.6679], zoom: 10} );
	
	L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap | HackaMinas' } ).addTo(mapa);
		
	function popUp(f,l){
		var out = [];
		if (f.properties){
			for(key in f.properties){
				out.push(key+": "+f.properties[key]);
			}
			l.bindPopup(out.join("<br />"));
		}
	}
	
	var jsonTest = new L.GeoJSON.AJAX(["http://localhost/hackaton/application/views/geojson.php"],{onEachFeature:popUp}).addTo(mapa);
	
	var jsonTest2 = new L.GeoJSON.AJAX(["http://localhost/hackaton/application/views/bueiros.geojson"],{onEachFeature:popUp}).addTo(mapa);
	
	var jsonTest3 = new L.GeoJSON.AJAX(["http://localhost/hackaton/application/views/bueiros2.geojson"],{onEachFeature:popUp}).addTo(mapa);
	
	var myIcon = L.icon({
		iconUrl: '<?php echo base_url("application/views/") . "dist/img/bueiro.png"; ?>',
		iconSize: [64, 64],
	});
	L.marker([-23.517026, -46.646229], {icon: myIcon}).addTo(mapa);
	L.marker([-23.518256, -46.636166], {icon: myIcon}).addTo(mapa);
	L.marker([-23.468649, -46.528587], {icon: myIcon}).addTo(mapa);
	L.marker([-23.433401, -46.512703], {icon: myIcon}).addTo(mapa);
	L.marker([-23.543330, -46.678920], {icon: myIcon}).addTo(mapa);
	L.marker([-23.884402, -46.953177], {icon: myIcon}).addTo(mapa);
	L.marker([-23.220030, -46.630020], {icon: myIcon}).addTo(mapa);
	L.marker([-23.220030, -47.630020], {icon: myIcon}).addTo(mapa);
	L.marker([-23.255350, -47.956890], {icon: myIcon}).addTo(mapa);
	L.marker([-22.540033, -48.610022], {icon: myIcon}).addTo(mapa);
	L.marker([-23.640033, -46.710022], {icon: myIcon}).addTo(mapa);
	L.marker([-24.640033, -48.710022], {icon: myIcon}).addTo(mapa);
	L.marker([-21.760003, -47.830011], {icon: myIcon}).addTo(mapa);
	
</script>

  