//Calculo IMC

$(document).ready(function(){
	$("#calcular").click(function() {
	
		$("#imc").html("");
	
		var peso = $("#peso").val();
		var altura = $("#altura").val();
		
		if ((peso != 0) && (altura != 0)){
		
			var imc = peso / (altura * altura);
			var status = "";
			
			if (imc >= 30){
				status = "Obeso";
			}
			else if (imc >= 25){
				status = "Sobrepeso (acima do peso desejado)";
			}
			else if (imc >= 18.5){
				status = "Peso normal";
			}
			else{
				status = "Abaixo do peso";
			}
			
			$("#imc").html("<b>" + imc.toFixed(2) + "</b> - " + status);
			$("#imc_field").val(imc);

		}
			
	});
});
