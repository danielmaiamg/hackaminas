<?php

class Json2_Model extends CI_Model {

    public function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		
    }
	
	public function QuantReformaLimpeza(){
	
		$sql = "SELECT count(*) AS quant FROM json2 WHERE (servico = 'Reforma de bueiros, boca de lobo e poços de visita' OR servico = 'Limpeza de bueiros, boca de lobo e poços de visita') ";
 		
		$consulta = $this->db->query($sql);
		
		$dados = array();
		
		if ($consulta->num_rows() > 0){
			$linha = $consulta->row();
			
			$dados = array(
			  'quant' => $linha->quant
			);
						
		}
		
		return $dados;
	
	}

	public function QuantReforma(){
	
		$sql = "SELECT count(*) AS quant FROM json2 WHERE (servico = 'Reforma de bueiros, boca de lobo e poços de visita') ";
 		
		$consulta = $this->db->query($sql);
		
		$dados = array();
		
		if ($consulta->num_rows() > 0){
			$linha = $consulta->row();
			
			$dados = array(
			  'quant' => $linha->quant
			);
						
		}
		
		return $dados;
	
	}

	public function QuantLimpeza(){
	
		$sql = "SELECT count(*) AS quant FROM json2 WHERE (servico = 'Limpeza de bueiros, boca de lobo e poços de visita') ";
 		
		$consulta = $this->db->query($sql);
		
		$dados = array();
		
		if ($consulta->num_rows() > 0){
			$linha = $consulta->row();
			
			$dados = array(
			  'quant' => $linha->quant
			);
						
		}
		
		return $dados;
	
	}

	public function QuantRisco($termos){
	
		$sql = "SELECT count(*) AS quant FROM json2 WHERE (servico = 'Reforma de bueiros, boca de lobo e poços de visita' OR servico = 'Limpeza de bueiros, boca de lobo e poços de visita') ";
		
		$cont = 1;
		
		foreach($termos as $palavra){
			if($cont == 1)
				$sql .= "AND (descricao_do_atendimento_ like '%" .$palavra. "%' ";
			else
				$sql .= "OR descricao_do_atendimento_ like '%" .$palavra. "%' ";
			
			$cont++;
		}
		
		if($cont > 1)
			$sql .= ")";
 		
		$consulta = $this->db->query($sql);
		
		$dados = array();
		
		if ($consulta->num_rows() > 0){
			$linha = $consulta->row();
			
			$dados = array(
			  'quant' => $linha->quant
			);
						
		}
		
		return $dados;
	
	}
	
}

?>