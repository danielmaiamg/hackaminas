<?php

class Usuario_Model extends CI_Model {

    public function __construct()
    {
        // Call the Model constructor
        parent::__construct();
		
    }
	
	public function QuantListarUsuarios(){

		$this->db->select('id_usuario');
		$this->db->from('usuario');

		return $this->db->count_all_results();

	}	
	
	public function ListarUsuarios($quant = 100000, $inicio = 0){
		
		$this->db->select('id_usuario, nome_usuario, email_usuario, perfil_usuario');
		$this->db->from('usuario');
		$this->db->order_by('nome_usuario ASC');
		$this->db->limit($quant, $inicio);
		
		$consulta = $this->db->get();
		
		$dados = array();
		
		foreach($consulta->result() as $linha){
			
			$acesso = "";
			
			switch($linha->perfil_usuario){
				case 1:
					$acesso = "GESTOR";
					break;
				case 2:
					$acesso = "MUNÍCIPE";
			
			}
							
			$dados[] = array(
							 'codigo'	=> $linha->id_usuario,
							 'nome'		=> $linha->nome_usuario,
							 'email'	=> $linha->email_usuario,
							 'perfil'	=> $linha->perfil_usuario,
							 'acesso'	=> $acesso
							 );
			
		}
		
		return $dados;
		
	}
		
	public function PegaUsuario($id){
		
		$this->db->select('id_usuario, nome_usuario, email_usuario, perfil_usuario');
		$this->db->from('usuario');
		$this->db->where('id_usuario', $id);
		
		$consulta = $this->db->get();
		
		$dados = array();
		
		if($consulta->num_rows() > 0){
	
			$linha = $consulta->row();			
			
			$dados = array(
							 'codigo'	=> $linha->id_usuario,
							 'nome'		=> $linha->nome_usuario,
							 'email'	=> $linha->email_usuario,
							 'perfil'	=> $linha->perfil_usuario
						);
			
		}

		return $dados;
		
	}
	    
	public function CriarUsuario($dados){

		$this->db->insert('usuario', $dados);
		
		return $this->db->affected_rows();
		
	}
	
	public function EditarUsuario($id, $dados){
		
		$this->db->where('id_usuario', $id);
		$this->db->update('usuario', $dados);
		
		return $this->db->affected_rows();		
	}
	
	public function ApagarUsuario($id){
		
		$this->db->where('id_usuario', $id);
		$this->db->delete('usuario');
		
		return $this->db->affected_rows();		
	}
	
	public function AlterarSenhaUsuario($id, $senha_atual, $senha_nova){
		
		$this->db->select('id_usuario, senha_usuario');
		$this->db->from('usuario');
		$this->db->where('id_usuario', $id);

		$consulta = $this->db->get();
		
		if($consulta->num_rows() > 0){
		
			$linha = $consulta->row();
			
			if(!strcmp($linha->senha_usuario, $senha_atual)){
				//altera senha do usuário
				
				$dados = array('senha_usuario' => $senha_nova);
				
				return $this->EditarUsuario($id, $dados);
				
			}
			
		}
		
		return 0;
		
	}
	
	public function BuscaSenha($id){
	
		$this->db->select('senha_usuario');
		$this->db->from('usuario');
		$this->db->where('id_usuario', $id);
		
		$consulta = $this->db->get();
		
		$dados = array();
		
		if($consulta->num_rows() > 0){
	
			$linha = $consulta->row();			
			
			$dados = array(
							 'senha'	=> $linha->senha_usuario
						);
			
		}

		return $dados;
	
	}
	
	public function AutenticarUsuario($email, $senha){
		
		$this->db->select('id_usuario, nome_usuario, email_usuario, senha_usuario, perfil_usuario');
		$this->db->from('usuario');
		$this->db->where('email_usuario', $email);
		
		$consulta = $this->db->get();
		
		$login = array();
		
		if($consulta->num_rows() > 0){
		
			$linha = $consulta->row();
			
			if(!strcmp($linha->senha_usuario, $senha)){
				//grava sessao do usuario em variavel
				
				$acesso = "";
				
				switch($linha->perfil_usuario){
					case 1:
						$acesso = "Gestor(a)";
						break;
					case 2:
						$acesso = "Munícipe";
						
				}
						
				
				$login = array(
							   	'ID' 	=> $linha->id_usuario,
								'NOME' 	=> $linha->nome_usuario,
								'EMAIL' => $linha->email_usuario,
								'PERFIL'=> $linha->perfil_usuario,
								'LOGON' => TRUE,
								'ACESSO'=> $acesso
								);
												
				
			}
			
		}
		
		return $login;
		
	}
	
}

?>