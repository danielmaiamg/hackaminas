<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        // Your own constructor code
		//$this->load->library('pagination');
		$this->load->model('Usuario_model', 'BDusuario');			
	}

	public function index()
	{
	
	}
	
	public function alterar_senha(){
	
		$permissao = 0;
		
		if($this->session->userdata('PERFIL') < 5) 
			$permissao = 1;		//se for o administrador, médico, operador ou psicologo permite
		
		if( ($this->session->userdata('LOGON')) && ($permissao) ){
				
			$this->load->view('main_header');
			$this->load->view('main_sidebar');
			$this->load->view('usuario_altsenha_form');
			$this->load->view('main_footer');
			
		}
		else{
		
			$msg['erro'] = "Acesso negado.";
			   
			$this->load->view('login', $msg);			
			
		}
	
	}
		
	public function gravar_alterar_senha(){
	
			$permissao = 0;
			
			if($this->session->userdata('PERFIL') < 5) 
				$permissao = 1;		//se for o administrador, médico, operador ou psicologo permite
			
			if( ($this->session->userdata('LOGON')) && ($permissao) ){
		   		
			   $regras = array(
							  array(
									'field' => 'senha_atual',
									'label' => 'Senha Atual',
									'rules' => 'trim|required'
									),
							  array(
									'field' => 'nova_senha',
									'label' => 'Nova Senha',
									'rules' => 'trim|required|min_length[5]|max_length[16]'
									),							   
							  array(
									'field' => 'cnova_senha',
									'label' => 'Confirma Nova Senha',
									'rules' => 'trim|required|matches[nova_senha]'
									)						  
									
							  );
										
				$this->form_validation->set_rules($regras);
				
			   
			   if($this->form_validation->run() == FALSE)
			    {
			   
					$this->load->view('error');
					
				}
			   else
			   {
				   
				   //busca senha atual do usuario para comparacao
				   $id_usuario = $this->session->userdata('ID');
				   
				   $senha = $this->BDusuario->BuscaSenha($id_usuario);
				   
				   if(!strcmp(md5($this->input->post('senha_atual')), $senha['senha'])){
						//altera senha do usuario
						$dados_usuario = array(
							'senha_usuario' => md5($this->input->post('nova_senha'))
						);
						
						$this->BDusuario->EditarUsuario($id_usuario, $dados_usuario);
						
						$retorno["msg"] = "Senha alterada com sucesso!";
								 
						$this->load->view('success', $retorno);
				   }
				   else{
						$retorno["msg"] = "A senha não pode ser alterada, pois não confere com a atual.";
								 
						$this->load->view('alert', $retorno);				   
				   }
				   				   				   
			   }
				
			}
			else{
			
				$msg['erro'] = "Acesso negado.";
				   
				$this->load->view('login', $msg);			
				
			}
			
	}
	
}
