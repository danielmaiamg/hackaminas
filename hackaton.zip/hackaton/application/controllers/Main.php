<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$termos = array('chuva', 'inunda', 'entupi', 'entope', 'enchente', 'alagamento');

class Main extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        // Your own constructor code
		$this->load->model('Usuario_model', 'BDusuario');
		$this->load->model('Json2_model', 'BDjson');

	}


	public function index()
	{

	    if($this->session->userdata('LOGON')){
			
			$dados['total'] = $this->BDjson->QuantReformaLimpeza();
			$dados['reforma'] = $this->BDjson->QuantReforma();
			$dados['limpeza'] = $this->BDjson->QuantLimpeza();
			
			global $termos;
			
			$dados['risco'] = $this->BDjson->QuantRisco($termos);
			
			$percentual = ($dados['risco']['quant'] / $dados['total']['quant']) * 100;
			$dados['risco_percentual'] = sprintf("%.2f",$percentual);
			
			//carrega visão de usuário logado	
			$this->load->view('main_header');
			$this->load->view('main_sidebar');
			$this->load->view('main_content', $dados);
			$this->load->view('main_footer');

		}
		else
		{
								   
		    $regras = array(
						  array(
								'field' => 'email',
								'label' => 'e-mail',
								'rules' => 'trim|required|valid_email|max_length[255]'
								),
						  array(
								'field' => 'senha',
								'label' => 'senha',
								'rules' => 'trim|required|min_length[5]|max_length[16]'
								)
						  );
									
			$this->form_validation->set_rules($regras);
			
		   
		   if($this->form_validation->run() == FALSE)
		   {
				
				$this->load->view('login');
				
		   }
		   else
		   {
			   
				$login = $this->BDusuario->AutenticarUsuario( $this->input->post('email'), md5($this->input->post('senha')) );
				
				if(!empty($login)){
				
					if($this->input->post('remember')):
						
						$cookie = array(
									'name' => 'remember_email',
									'value' => $this->input->post('email'),
									'expire' => '86400'		#24 horas
						);
						
						$this->input->set_cookie($cookie);
						
						$cookie = array(
									'name' => 'remember_password',
									'value' => $this->input->post('senha'),
									'expire' => '86400'		#24 horas
						);
						
						$this->input->set_cookie($cookie);
						
					else:

						$cookie = array(
									'name' => 'remember_email',
									'value' => ''
						);
						
						$this->input->set_cookie($cookie);
						
						$cookie = array(
									'name' => 'remember_password',
									'value' => ''
						);
						
						$this->input->set_cookie($cookie);					
						
					endif;
					
					//registra/confirma sessao do usuario
					$this->session->set_userdata($login);
					
					$dados['total'] = $this->BDjson->QuantReformaLimpeza();
					$dados['reforma'] = $this->BDjson->QuantReforma();
					$dados['limpeza'] = $this->BDjson->QuantLimpeza();
					
					global $termos;
					
					$dados['risco'] = $this->BDjson->QuantRisco($termos);
					
					$percentual = ($dados['risco']['quant'] / $dados['total']['quant']) * 100;
					$dados['risco_percentual'] = sprintf("%.2f",$percentual);
				
					//carrega visão de usuário logado					
					$this->load->view('main_header');
					$this->load->view('main_sidebar');
					$this->load->view('main_content', $dados);
					$this->load->view('main_footer');
					
				}else{
					
					$msg['erro'] = "Acesso negado: e-mail e/ou senha inexistentes ou incorretos.";
				   
					$this->load->view('login', $msg);
					
				}
				
				
		   }
	   
		} //if sessao já logada	
	
	}
	
	public function logout(){
		   
		$login = array(
						'ID' 	=> '',
						'NOME' 	=> '',
						'EMAIL' => '',
						'PERFIL'=> '',
						'LOGON' => FALSE,
						'ACESSO'=> ''
						);
		
		$this->session->unset_userdata($login);
		
		$this->session->sess_destroy();
					
		$this->load->view('login');
					
	}
	
}
